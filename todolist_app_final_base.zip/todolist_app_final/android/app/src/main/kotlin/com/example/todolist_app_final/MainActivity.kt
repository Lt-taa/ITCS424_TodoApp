package com.example.todolist_app_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
